package be.ugent.reeks1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Reeks1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
