package be.ugent.reeks1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Reeks1Application {

	public static void main(String[] args) {
		SpringApplication.run(Reeks1Application.class, args);
	}

}
